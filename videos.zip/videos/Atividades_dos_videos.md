﻿# Demonstração dos requisitos funcionais

Os vídeos mostram as principais funções da Clínica Simples, organizadas pelos requisitos funcionais do projeto.

| Vídeo | Atividade apresentada | Requisitos |
| --- | --- | --- |
| `cad_paciente.mp4` | Cadastro e listagem de pacientes, incluindo validação do CPF e consulta dos códigos gerados. | RF01 e RF02 |
| `cad_medico.mp4` | Cadastro e listagem de médicos, com verificação de CRM duplicado. | RF03 |
| `Agendar.mp4` | Criação de agendamentos e consulta da agenda com paciente, médico, data, horário e situação. | RF04 e RF05 |
| `Consulta.mp4` | Atualização da situação dos agendamentos — confirmação, cancelamento e falta — e registro de consultas com queixa, diagnóstico e conduta. | RF06, RF07, RF08 e RF09 |
| `Hist_Consultas.mp4` | Consulta do histórico de atendimentos do paciente. | RF10 |
| `Pagamento.mp4` | Registro, listagem e baixa de pagamentos vinculados a consultas. | RF11, RF12 e RF13 |
| `Relatório.mp4` | Consulta do total recebido em um período e da relação de pacientes com pagamentos pendentes. | RF14 e RF15 |

Em conjunto, os sete vídeos apresentam os **15 requisitos funcionais**. A imagem `REF-08eREF-13.webp` mostra um agendamento com a situação **Não compareceu**.
